#include <CL/cl.hpp>

#include <iostream>
#include "utilCL.h"

using namespace std;
using namespace cl;

int main() {
    cl_int              err;
    vector<Platform>    platforms;
    string              data;
    vector<Device>      devices;

    voStmt(Platform::get(&platforms));
    cerr << "Plataformas encontradas: " << platforms.size() << endl;

    for (int i = 0; i < platforms.size(); ++i) {
        voStmt(platforms[i].getInfo(CL_PLATFORM_VENDOR, &data));
        cerr << "\tPlataforma " << i << ":\n"
            << "\tFabricante: " << data << endl;

        voStmt(platforms[i].getDevices(CL_DEVICE_TYPE_ALL, &devices));
        cerr << "\tDispositivos encontrados: " << devices.size() << endl;
        for (int j = 0; j < devices.size(); ++j) {
            voStmt(devices[i].getInfo(CL_DEVICE_NAME, &data));
            cerr << "\t\tDispositivo " << i << ":\n"
                << "\t\tNombre: " << data << endl;
        }
    }
    return EXIT_SUCCESS;
}
