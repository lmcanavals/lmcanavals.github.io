#include <stdio.h>
#include <stdlib.h>

#include <CL/cl.h>

#define voCheck(stmt)                           \
  do                                            \
  {                                             \
    cl_int _err = stmt;                         \
    if (_err != CL_SUCCESS)                     \
    {                                           \
      printf("Failed to run %d \n", #stmt);     \
      return EXIT_FAILURE;                      \
    }                                           \
  } while(0)

#define MEM_SIZE (1000000)

int main() {
	cl_device_id device_id = NULL;
	cl_context context = NULL;
	cl_command_queue command_queue = NULL;
	cl_mem memobjA = NULL;
	cl_mem memobjB = NULL;
	cl_mem memobjC = NULL;
	cl_program program = NULL;
	cl_kernel kernel = NULL;
	cl_platform_id platform_id = NULL;
	cl_uint ret_num_devices;
	cl_uint ret_num_platforms;
	cl_int ret;

	float a[MEM_SIZE];
	float b[MEM_SIZE];
	float c[MEM_SIZE];

	FILE *fp;
	char fileName[] = "./opencl002suma.cl";
	char *source_str;
	size_t source_size;

	for (int i = 0; i < MEM_SIZE; ++i) {
		a[i] = i;
		b[i] = MEM_SIZE - i;
		c[i] = 0.0f;
	}

	fp = fopen(fileName, "r");
	if (!fp) {
		fprintf(stderr, "Failed to load kernel.\n");
		exit(1);
	}
	fseek(fp, 0, SEEK_END);
	source_size = ftell(fp) + 10;
	source_str = (char*) malloc(source_size);
	source_size = fread(source_str, 1, source_size, fp);
	fclose(fp);
	
	voCheck(clGetPlatformIDs(1, &platform_id, &ret_num_platforms));
	voCheck(clGetDeviceIDs(platform_id, CL_DEVICE_TYPE_DEFAULT, 1, &device_id, &ret_num_devices));

	context = clCreateContext(NULL, 1, &device_id, NULL, NULL, &ret);

	command_queue = clCreateCommandQueueWithProperties(context, device_id, 0, &ret);

	memobjA = clCreateBuffer(context, CL_MEM_READ_WRITE, MEM_SIZE * sizeof(float), NULL, &ret);
	memobjB = clCreateBuffer(context, CL_MEM_READ_WRITE, MEM_SIZE * sizeof(float), NULL, &ret);
	memobjC = clCreateBuffer(context, CL_MEM_READ_WRITE, MEM_SIZE * sizeof(float), NULL, &ret);

	program = clCreateProgramWithSource(context, 1, (const char **)&source_str,
	(const size_t *)&source_size, &ret);

	voCheck(clBuildProgram(program, 1, &device_id, NULL, NULL, NULL));

	kernel = clCreateKernel(program, "sumar", &ret);

	voCheck(clSetKernelArg(kernel, 0, sizeof(cl_mem), (void *)&memobjA));
	voCheck(clSetKernelArg(kernel, 1, sizeof(cl_mem), (void *)&memobjB));
	voCheck(clSetKernelArg(kernel, 2, sizeof(cl_mem), (void *)&memobjC));

	voCheck(clEnqueueTask(command_queue, kernel, 0, NULL,NULL));

	voCheck(clEnqueueReadBuffer(command_queue, memobjC, CL_TRUE, 0, 
							  MEM_SIZE * sizeof(float), c, 0, NULL, NULL));

	/* Display Result */
	for (int i = 0; i < 20; ++i) {
		printf("%f + %f = %f\n", a[i],b[i], c[i]);
	}

	/* Finalization */
	voCheck(clFlush(command_queue));
	voCheck(clFinish(command_queue));
	voCheck(clReleaseKernel(kernel));
	voCheck(clReleaseProgram(program));
	voCheck(clReleaseMemObject(memobjA));
	voCheck(clReleaseMemObject(memobjB));
	voCheck(clReleaseMemObject(memobjC));
	voCheck(clReleaseCommandQueue(command_queue));
	voCheck(clReleaseContext(context));

	return 0;
}
