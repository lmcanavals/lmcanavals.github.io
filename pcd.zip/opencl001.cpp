#include <utility>
#include <CL/cl.hpp>

#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <iostream>
#include <string>
#include <iterator>

#include "utilCL.h"

using namespace std;
using namespace cl;

int main() {
    cl_int              err;
    vector<Platform>    platforms;
    vector<Device>      devices;
    Event               event;
    Context             context;
    CommandQueue        queue;
    Buffer              mem;
    Program::Sources    source;
    Program             program;
    Kernel              kernel;

    cl_int              len = 14; // Hola, Mundo!\n
    char*               str = new char[len];


    ifstream file("opencl001.cl");
    if (!file.is_open()) return EXIT_FAILURE;
    string prog(istreambuf_iterator<char>(file), (istreambuf_iterator<char>()));
    file.close();

    voStmt(Platform::get(&platforms));
    voStmt(platforms[0].getDevices(CL_DEVICE_TYPE_DEFAULT, &devices));

    context = Context({devices[0]});

    queue = CommandQueue(context, devices[0], 0, &err); voErr(err);

    mem = Buffer(context, CL_MEM_WRITE_ONLY | CL_MEM_USE_HOST_PTR, len, str, &err); voErr(err);
    source = Program::Sources(1, make_pair(prog.c_str(), prog.length()+1));
    program = Program(context, source);

    voStmt(program.build(devices, ""));

    kernel = Kernel(program, "holaa", &err); voErr(err);

    voStmt(kernel.setArg(0, mem));

    voStmt(queue.enqueueNDRangeKernel(kernel, NullRange,
        NDRange(len), NDRange(1, 1), NULL, &event));

    event.wait();
    voStmt(queue.enqueueReadBuffer(mem, CL_TRUE, 0, len, str));
    std::cout << str;

    return EXIT_SUCCESS;
}
