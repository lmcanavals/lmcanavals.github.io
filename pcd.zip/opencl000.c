#include <stdio.h>
#include <stdlib.h>

#include <CL/cl.h>
#include "utilCL.h"

#define MAXLEN 1000

int main() {
	char            buf[MAXLEN];
	cl_uint         plat_count;
	cl_platform_id* platforms;
    cl_uint         dev_count;
    cl_device_id*   devices;


	voStmt(clGetPlatformIDs(0, NULL, &plat_count));                            // obtener cantidad de plataformas
	platforms = (cl_platform_id*) malloc(plat_count * sizeof(cl_platform_id));
	voStmt(clGetPlatformIDs(plat_count, platforms, NULL));                     // obtener ids de plataformas

    for (int i = 0; i < plat_count; ++i) {                                      // para cada plataforma:
        voStmt(clGetPlatformInfo(platforms[i], CL_PLATFORM_VENDOR,             //   obtener nombre de fabricante de plataforma[i]
                                  sizeof(buf), buf, NULL));
        printf("Plataforma %3d: fabricante '%s'\n", i, buf);

        voStmt(clGetDeviceIDs(platforms[i], CL_DEVICE_TYPE_ALL,                //   obtener cantidad de dispositivos
        					   0, NULL, &dev_count));

        devices = (cl_device_id*) malloc(dev_count * sizeof(cl_device_id));
        voStmt(clGetDeviceIDs(platforms[i], CL_DEVICE_TYPE_ALL,                //   obtener ids de dispositivos
        					   dev_count, devices, NULL));

        for (int j = 0; j < dev_count; ++j)	{                                   //   para cada dispositivo
            voStmt(clGetDeviceInfo(devices[i], CL_DEVICE_NAME,                 //     obtener nombre del dispositivo
        						    sizeof(buf), buf, NULL));
        	printf("\tDispositivo %3d: '%s'\n", j, buf);
        }
        free(devices);
	}
	free(platforms);
	return 0;
}
